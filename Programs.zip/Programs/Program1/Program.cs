﻿using System;
using System.IO;
using System.Collections.Generic;

// Program to determine the smallest temperature spread from a data file
namespace Program1
{
	class Program
	{
		public static void Main()
		{
			string fileName = "w_data.dat"; 
			string delimeter = " "; 
			char specialChar = '*'; 
			string line, trimLine, output;
			string[] fields;
			int day;
			double tempMin, tempMax, tempSpread;	
			List<int> daysList = new List<int>();
			List<double> tempSpreadList = new List<double>();

			try
			{   // Open file
				using (StreamReader sr = new StreamReader(fileName))
				{
					// Read each line until the end
					while ((line = sr.ReadLine()) != null) 
					{
						// Remove blank spaces around each line; ignore blank lines
						trimLine = line.Trim();
						if (trimLine.Length > 0)
						{
							// Only interested in data which starts with a number
							if (Char.IsNumber(trimLine, 0))
							{
								// Only interested in the first 3 fields of each line, with the rest thrown into the remainder
								fields = trimLine.Split(delimeter, 4, StringSplitOptions.RemoveEmptyEntries);

								try
								{	// Get the temperature spread for this day
									day = Int32.Parse(fields[0]);
									tempMax = Double.Parse(fields[1].Trim(specialChar));
									tempMin = Double.Parse(fields[2].Trim(specialChar));
									tempSpread = tempMax - tempMin;
								}
								catch (Exception e)
								{
									// Skip over lines with formatting errors
									Console.WriteLine("Cannot convert data: " + e.Message);
									continue;
								}

								// Add to the List of pertinent info
								daysList.Add(day);
								tempSpreadList.Add(tempSpread);
							}
						}
					}

					// Convert the lists into arrays for easy sorting
					int[] days = daysList.ToArray();
					double[] tempSpreads = tempSpreadList.ToArray();
					Array.Sort(tempSpreads, days);

					// After sorting, the first element is the smallest one
					output = days[0].ToString();
					Console.WriteLine("Smallest temperature spread is for day " + output);
				}
			}
			catch (Exception e)
			{
				Console.WriteLine("Cannot read file: ");
				Console.WriteLine(e.Message);
			}
		}
	}
}
