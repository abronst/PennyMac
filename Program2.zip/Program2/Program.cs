﻿using System;
using System.IO;
using System.Collections.Generic;

// Program to determine the team with the smallest difference in goals from a data file
namespace Program2
{
	class Program
	{
		public static void Main()
		{
			string fileName = "soccer.dat"; 
			string delimeter = " "; 
			string line, trimLine, output;
			string[] fields;
			string team;
			int forGoals, againstGoals, goalSpread;	
			List<int> goalsList = new List<int>();
			List<string> teamList = new List<string>();

			try
			{   // Open file
				using (StreamReader sr = new StreamReader(fileName))
				{
					// Read each line until the end
					while ((line = sr.ReadLine()) != null) 
					{
						// Remove blank spaces around each line; ignore blank lines
						trimLine = line.Trim();
						if (trimLine.Length > 0)
						{
							// Only interested in data which starts with a number
							if (Char.IsNumber(trimLine, 0))
							{
								// Split into fields
								fields = trimLine.Split(delimeter, 10, StringSplitOptions.RemoveEmptyEntries);
								
								try
								{	// Get the name of the team and the goals; calculate the spread
									team = fields[1];
									forGoals = Int32.Parse(fields[6].Trim());
									againstGoals = Int32.Parse(fields[8].Trim());
									goalSpread = Math.Abs(forGoals - againstGoals);
								}
								catch (Exception e)
								{
									// Skip over lines with formatting errors
									Console.WriteLine("Cannot convert data: " + e.Message);
									continue;
								}

								// Add to the List of pertinent info
								teamList.Add(team);
								goalsList.Add(goalSpread);
							}
						}
					}
					
					// Convert the lists into arrays for easy sorting
					int[] goals = goalsList.ToArray();
					string[] teams = teamList.ToArray();
					Array.Sort(goals, teams);

					// After sorting, the first element is the smallest one
					output = teams[0].ToString();
					Console.WriteLine("Team with the smallest difference in goals: " + output);
				}
			}
			catch (Exception e)
			{
				Console.WriteLine("Cannot read file: ");
				Console.WriteLine(e.Message);
			}
		}
	}
}
